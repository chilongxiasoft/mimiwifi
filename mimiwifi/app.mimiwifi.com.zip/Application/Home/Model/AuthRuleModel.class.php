<?php
// +----------------------------------------------------------------------
// | MIMIWIFI
// +----------------------------------------------------------------------
// | Copyright (c) 2014 http://www.mimiwifi.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: @author a-ze <592358@qq.com>
// +----------------------------------------------------------------------

namespace Home\Model;
use Think\Model;
/**
 * 权限规则模型
 * @author a-ze <592358@qq.com>
 */
class AuthRuleModel extends Model{
    
    const RULE_URL = 1;
    const RULE_MAIN = 2;

}
